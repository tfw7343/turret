# python_arudino_turret
"desciptions are stupid"
- Terence
